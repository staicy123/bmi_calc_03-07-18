package com.mvc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.mvc.bean.RegisterBean;
import com.mvc.util.DBConnection;
 
public class RegisterDao {
 
 public String registerUser(RegisterBean registerBean)
 {
 String firstName = registerBean.getFirstname();
String lastName= registerBean.getLastname();
 String email=registerBean.getEmail();
 String dob=registerBean.getDob();
String gender= registerBean.getGender();
 String phoneNumber=registerBean.getPhone_number();
 String userName =registerBean.getUsername();
 String password = registerBean.getPassword(); 

 
 Connection con = null;
 PreparedStatement preparedStatement = null;
 
 try
 {
 con = DBConnection.createConnection();
 String query = "insert into sm_user_registration(first_name,last_name,dob,gender,phone_number,email,username,password) values (?,?,?,?,?,?,?,?)"; //Insert user details into the table 'USERS'
 preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
 preparedStatement.setString(1, firstName);
 preparedStatement.setString(2, lastName);
 preparedStatement.setString(3, dob);
 preparedStatement.setString(4, gender);
 preparedStatement.setString(5, phoneNumber);
 preparedStatement.setString(6, email);
 preparedStatement.setString(7, userName);
 preparedStatement.setString(8, password);
 
 
 
 int i= preparedStatement.executeUpdate();
 
 if (i!=0)  //Just to ensure data has been inserted into the database
 return "SUCCESS"; 
 }
 catch(SQLException e)
 {
 e.printStackTrace();
 }
 
 return "Oops.. Something went wrong there..!";  // On failure, send a message from here.
 }
}

