package com.mvc.bean;

public class BMIWeeklyReportBean {

	private int bmi_id;
	private int user_id;
	private int category_id;
	private int weight;
	private int height;
	private double bmi_value;
	private String category_name;
	private String obesity_classification;
	private String relative_risk;
	private String username;
	private String date;


	public BMIWeeklyReportBean() {
		super();
	}
	public int getBmi_id() {
		return bmi_id;
	}
	public void setBmi_id(int bmi_id) {
		this.bmi_id = bmi_id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public int getCategory_id() {
		return category_id;
	}
	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public double getBmi_value() {
		return bmi_value;
	}
	public void setBmi_value(double bmi_value) {
		this.bmi_value = bmi_value;
	}
	public String getCategory_name() {
		return category_name;
	}
	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}
	public String getObesity_classification() {
		return obesity_classification;
	}
	public void setObesity_classification(String obesity_classification) {
		this.obesity_classification = obesity_classification;
	}
	public String getRelative_risk() {
		return relative_risk;
	}
	public void setRelative_risk(String relative_risk) {
		this.relative_risk = relative_risk;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}





}
