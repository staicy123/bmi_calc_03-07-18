package com.mvc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mvc.bean.LoginBean;
import com.mvc.util.DBConnection;
import com.mvc.util.DBConnection1;
public class LoginDao {


	public String authenticateUser(LoginBean loginBean)
	{

		String userName = loginBean.getUserName(); //Keeping user entered values in temporary variables.
		String password = loginBean.getPassword();

		Connection con = null;
		
		ResultSet resultSet = null;
		ResultSet resultSet1 = null;
		PreparedStatement ps = null;
		PreparedStatement ps1 = null;
		String userNameDB = "";
		String passwordDB = "";


		try
		{
			con = DBConnection1.createConnection();
			//statement = con.createStatement();
			ps = con.prepareStatement("select username,password from user_registration where username=? && password=?");
			ps.setString(1, userName);
			ps.setString(2, password);
			resultSet = ps.executeQuery();
			
			ps1 = con.prepareStatement("select username,password from admin_registration where username=? && password=?");
			ps1.setString(1, userName);
			ps1.setString(2, password);
			resultSet1 = ps1.executeQuery();
			
			if(resultSet.next()) // Until next row is present otherwise it return false
			{
				userNameDB = resultSet.getString("username"); //fetch the values present in database
				passwordDB = resultSet.getString("password");
				System.out.println("username"+userNameDB);


				if(userName.equals(userNameDB) && password.equals(passwordDB))
				{
					return "SUCCESS"; 
				}

			}
			else if(resultSet1.next()==true){
				userNameDB = resultSet1.getString("username"); //fetch the values present in database
				passwordDB = resultSet1.getString("password");
				


				if(userName.equals(userNameDB) && password.equals(passwordDB))
				{
					return "SUCCESS1"; 
				}

				
			}

		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return "NOT_USER"; // Just returning appropriate message otherwise

	}
}
