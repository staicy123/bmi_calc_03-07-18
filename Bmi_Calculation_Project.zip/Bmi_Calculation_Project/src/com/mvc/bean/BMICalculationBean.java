package com.mvc.bean;

public class BMICalculationBean {
	
	private int bmi_id;
	private int centimeter;
	private float meter;
	private int feet;
	private int inch;
	private float kilogram;
	private int pounds;
	private double bmi_calculated_value;
	private String date;
	private String day;
	private AddCategoryBean addcategorybean;
	
	
	public BMICalculationBean(BMICalculationBean bmicalc,AddCategoryBean addcategorybean)
	{
		
		this.addcategorybean=addcategorybean;
	}
	public BMICalculationBean(int centimeter, float kilogram, double bmi_calculated_value) {
		super();
		this.centimeter = centimeter;
		this.kilogram = kilogram;
		this.bmi_calculated_value=bmi_calculated_value;
	}
	public BMICalculationBean(int bmi_id, double bmi_calculated_value,AddCategoryBean addcategorybean) {
		super();
		this.bmi_id=bmi_id;
		this.bmi_calculated_value=bmi_calculated_value;
		this.addcategorybean=addcategorybean;
	}
	public BMICalculationBean(float meter, float kilogram, double bmi_calculated_value) {
		super();
		this.meter = meter;
		this.kilogram = kilogram;
		this.bmi_calculated_value=bmi_calculated_value;
	}
	public BMICalculationBean(int inch, int pounds, double bmi_calculated_value) {
		super();
		this.inch = inch;
		this.pounds = pounds;
		this.bmi_calculated_value=bmi_calculated_value;
	}
	public BMICalculationBean(int feet, int inch, int pounds, double bmi_calculated_value) {
		super();
		this.feet = feet;
		this.inch = inch;
		this.pounds = pounds;
		this.bmi_calculated_value=bmi_calculated_value;
	}
	public BMICalculationBean() {
		super();
	}
	public int getCentimeter() {
		return centimeter;
	}
	public void setCentimeter(int centimeter) {
		this.centimeter = centimeter;
	}
	public float getMeter() {
		return meter;
	}
	public void setMeter(float meter) {
		this.meter = meter;
	}
	public int getFeet() {
		return feet;
	}
	public void setFeet(int feet) {
		this.feet = feet;
	}
	public int getInch() {
		return inch;
	}
	public void setInch(int inch) {
		this.inch = inch;
	}
	public float getKilogram() {
		return kilogram;
	}
	public void setKilogram(float kilogram) {
		this.kilogram = kilogram;
	}
	public int getPounds() {
		return pounds;
	}
	public void setPounds(int pounds) {
		this.pounds = pounds;
	}
	public double getBmi_calculated_value() {
		return bmi_calculated_value;
	}
	public void setBmi_calculated_value(double bmi_calculated_value) {
		this.bmi_calculated_value = bmi_calculated_value;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getBmi_id() {
		return bmi_id;
	}
	public void setBmi_id(int bmi_id) {
		this.bmi_id = bmi_id;
	}
	public AddCategoryBean getAddcategorybean() {
		return addcategorybean;
	}
	public void setAddcategorybean(AddCategoryBean addcategorybean) {
		this.addcategorybean = addcategorybean;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	
	
	
}
