package com.mvc.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.itextpdf.text.DocumentException;
import com.mvc.bean.BMIWeeklyReportBean;
import com.mvc.dao.DownloadFileDao;

/**
 * Servlet implementation class DownloadFileServlet
 */
public class DownloadFileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DownloadFileServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String username=(String)request.getSession().getAttribute("username");
		HttpSession session = request.getSession();
		
		BMIWeeklyReportBean bmiweeklyreport = new BMIWeeklyReportBean();
		DownloadFileDao dwnldfile = new DownloadFileDao();
		try {
			String status=dwnldfile.getTheFile(bmiweeklyreport, username);
			if(status.equals("Success")){

				session.setAttribute("username", username);
				request.setAttribute("errMessage", "Download Completed"); 
				request.getRequestDispatcher("/weekly_report.jsp").forward(request, response);
			}
			else{
				
				session.setAttribute("username", username);
				request.setAttribute("errMessage", "Unable to download"); 
				request.getRequestDispatcher("/message_display.jsp").forward(request, response);
				
			}
		} catch (ClassNotFoundException | DocumentException e) {
			
			e.printStackTrace();
		}
		
	}
	

}
