package com.mvc.bean;

public class AddCategoryBean {
	
	private String category_name;
	private String classification;
	private String risk_classification;
	
	
	
	public AddCategoryBean() {
		super();
	}
	public AddCategoryBean(String category_name, String classification) {
		super();
		this.category_name = category_name;
		this.classification = classification;
	}
	public String getCategory_name() {
		return category_name;
	}
	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}
	public String getClassification() {
		return classification;
	}
	public void setClassification(String classification) {
		this.classification = classification;
	}
	public String getRisk_classification() {
		return risk_classification;
	}
	public void setRisk_classification(String risk_classification) {
		this.risk_classification = risk_classification;
	}
	
	
	

}
