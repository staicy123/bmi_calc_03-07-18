package com.mvc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;



import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.CMYKColor;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;






import com.mvc.bean.BMIWeeklyReportBean;
import com.mvc.util.DBConnection;

public class DownloadFileDao {
	
	public String getTheFile(BMIWeeklyReportBean bmiweeklyreportbean,String username) throws ClassNotFoundException, FileNotFoundException, DocumentException{
		
		
		
		Connection con = null;
	

		ResultSet resultSet = null;
		ResultSet resultSet1 = null;
		ResultSet resultSet2 = null;
		ResultSet resultSet3 = null;
		PreparedStatement ps = null;
		PreparedStatement ps1= null;
		PreparedStatement ps2= null;
		PreparedStatement ps3=null;
		String week_date=null;
		int user_id=0;
		String sys_date=null;
		/*vacancy=(VacancyList) vacant.newInstance();*/

		Document document = new Document(PageSize.A4, 10, 10, 10, 10);
		 ByteArrayOutputStream baos = new ByteArrayOutputStream();
		PdfWriter writer = PdfWriter.getInstance(document,new FileOutputStream("D:\\weeklyreport.pdf"));
		
		document.open();
		Paragraph para1 = new Paragraph("Candidates by qualification",FontFactory.getFont(FontFactory.HELVETICA, 16, Font.BOLD, new CMYKColor(60, 40, 40, 100)));
		document.add(para1);
		PdfPTable t = new PdfPTable(7);
			t.setSpacingBefore(25);
			t.setSpacingAfter(25);
			PdfPCell c1 = new PdfPCell(new Phrase("Day"));		t.addCell(c1);
			PdfPCell c2 = new PdfPCell(new Phrase("Height in inches/cm"));				t.addCell(c2);
			PdfPCell c3 = new PdfPCell(new Phrase("Weight in kg/pounds"));		t.addCell(c3);
			PdfPCell c4 = new PdfPCell(new Phrase("BMI"));	t.addCell(c4);
			PdfPCell c5 = new PdfPCell(new Phrase("Classification"));				t.addCell(c5);
			PdfPCell c6 = new PdfPCell(new Phrase("Obesity Classification"));		t.addCell(c6);
			PdfPCell c7 = new PdfPCell(new Phrase("Relative Risk Classification"));	t.addCell(c7);
		
		try
		{

			con = DBConnection.createConnection();
			ps = con.prepareStatement("select CURDATE()");
			resultSet=ps.executeQuery();
			if(resultSet.next())
			{

				week_date= resultSet.getString(1);
			}
			System.out.println("week_date"+week_date);
			ps1 = con.prepareStatement("select user_id from sm_user_registration where username=?");
			ps1.setString(1, username);
			resultSet1=ps1.executeQuery();
			if(resultSet1.next()==true)
			{

				user_id= resultSet1.getInt("user_id");
			}

			System.out.println("user_id"+user_id);
			System.out.println("username:"+username);
			ps2 = con.prepareStatement("select CURDATE()");

			resultSet2=ps2.executeQuery();
			if(resultSet2.next())
			{

				sys_date= resultSet2.getString("CURDATE()");
			}
			/*System.out.println("sys_date"+sys_date);*/

			ps3= con.prepareStatement("select b.day,b.height,b.weight,b.bmi_calculated_value,c.classification,c.obesity_classification,"
					+ "c.relative_risk_classification from sm_bmi_details  b inner join sm_category c on b.category_id=c.category_id where b.user_id=?  "
					+ "AND b.calculated_date=?");
			ps3.setInt(1, user_id);
			ps3.setString(2,week_date);
			
			resultSet3 = ps3.executeQuery();
			while(resultSet3.next())
			{
				t.addCell(resultSet3.getString(1));
				
				t.addCell(resultSet3.getString(2));
				
				t.addCell(resultSet3.getString(3));
				
				t.addCell(resultSet3.getString(4));
				
				t.addCell(resultSet3.getString(5));
				
				t.addCell(resultSet3.getString(6));
				
				t.addCell(resultSet3.getString(7));
			
				
			}
			document.add(t);
			document.close();
			System.out.println("\tPDF download complete");
			
			return "Success";
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (Exception e) {
		
			e.printStackTrace();

		}
	
	return "failed to download";
		
		
	}

}
