package com.mvc.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mvc.bean.RegisterBean;
import com.mvc.dao.RegisterDao;

/**
 * Servlet implementation class EditRegistrationServlet
 */
@WebServlet("/EditRegistrationServlet")
public class EditRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditRegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String username=(String)request.getSession().getAttribute("username");
		String edit=request.getParameter("action");
		HttpSession session = request.getSession();
		if(edit.equals("edit")){
			
			RegisterBean regbean = new RegisterBean();
			RegisterDao regdao = new RegisterDao();
			RegisterBean regobj=regdao.editRegistration(regbean,username);
			String firstname=regobj.getFirstname();
			System.out.println("firstname"+firstname);
			request.setAttribute("firstname", firstname);
			request.setAttribute("lastname", regobj.getLastname());
			request.setAttribute("dob", regobj.getDob());
			request.setAttribute("phone", regobj.getPhone_number());
			request.setAttribute("email", regobj.getEmail());
			
			session.setAttribute("username", username);
			request.getRequestDispatcher("/edit-registration.jsp").forward(request, response);
			
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
