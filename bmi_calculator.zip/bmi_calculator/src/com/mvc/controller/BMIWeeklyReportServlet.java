package com.mvc.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mvc.bean.BMIWeeklyReportBean;
import com.mvc.dao.BMIWeeklyReportDao;

/**
 * Servlet implementation class BMIWeeklyReportServlet
 */
@WebServlet("/BMIWeeklyReportServlet")
public class BMIWeeklyReportServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BMIWeeklyReportServlet() {
        super();
       
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String weekly= request.getParameter("action");
		
		
		if(weekly.equals("week")){
			
			String username=(String)request.getSession().getAttribute("username");
			HttpSession session = request.getSession();
		System.out.println("servlet name"+username);
		BMIWeeklyReportDao bmiweeklyreportdao =  new BMIWeeklyReportDao();
		BMIWeeklyReportBean bmiweeklyreportbmi = new BMIWeeklyReportBean();
	
	
			List<BMIWeeklyReportBean> bmiweeklyreportbmi1 = null;
			try {
				bmiweeklyreportbmi1 = bmiweeklyreportdao.getUserWeeklyReport(username,bmiweeklyreportbmi);
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(bmiweeklyreportbmi1!=null){
				
				session.setAttribute("username", username);
				request.setAttribute("bmilist", bmiweeklyreportbmi1);
				request.getRequestDispatcher("/weekly_report.jsp").forward(request, response);
				
			}
			else{
				
			
				session.setAttribute("username", username);
				request.getRequestDispatcher("/weekly_report.jsp").forward(request, response);
			}
			
		
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	//	doGet(request, response);
		
		
	}

}
