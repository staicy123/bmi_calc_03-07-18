package com.luv2code.springdemo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
@RequestMapping("/silly")
public class SillyController {
	
	@RequestMapping("/studentForm")
	
	public String displayForm(){
		
		return "studentform";
	}
	
	
	@RequestMapping("/processForm")
	public String letsShoutDude(@RequestParam("firstname") String name,Model model){
		
		
		name= name.toUpperCase();
		String result= "My result is"+name;
		model.addAttribute("name", name);
		return "processform";
		
	}
	

}
