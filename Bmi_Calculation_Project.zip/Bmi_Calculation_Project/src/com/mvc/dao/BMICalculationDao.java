package com.mvc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.mvc.bean.BMICalculationBean;
import com.mvc.util.DBConnection;

public class BMICalculationDao {
	
	
	public String getBMIValue(BMICalculationBean bmicalculationbean,String username,String result){
		
		int height=bmicalculationbean.getInch();
		
		int weight= bmicalculationbean.getPounds();
		double bmi= bmicalculationbean.getBmi_calculated_value();
		 int height_in_cm =bmicalculationbean.getCentimeter();
		 float weight_in_kg = bmicalculationbean.getKilogram();
		
		Connection con= null;
		PreparedStatement ps=null;
		PreparedStatement ps1=null;
		PreparedStatement ps2=null;
		PreparedStatement ps3=null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;
	
		int user_id=0;
		int category_id=0;
		int bmi_id=0;
		String sys_date=null;
		if(height!=0 &&  weight!=0){
		try{
			
			con= DBConnection.createConnection();
			
			String sql1="select user_id from sm_user_registration where username=?";
			ps1=con.prepareStatement(sql1);
			ps1.setString(1, username);
			rs= ps1.executeQuery();
			while(rs.next()){
				user_id=rs.getInt("user_id");
			}
			System.out.println("user_id"+user_id);
			String sql2="select category_id from sm_category where classification=?";
			ps2=con.prepareStatement(sql2);
			ps2.setString(1, result);
			rs1= ps2.executeQuery();
			while(rs1.next()){
				category_id=rs1.getInt("category_id");
			}
			System.out.println("cat_id"+category_id);
			String sql4="select sysdate from dual";
			ps3=con.prepareStatement(sql4);
			rs2=ps3.executeQuery();
			if(rs2.next()==true){
				sys_date=rs2.getString("sysdate");
			}
			System.out.println(sys_date);
				
			
				
		
			String sql3="insert into sm_bmi_details(user_id,category_id, height,weight,bmi_calculated_value,calculated_date) values(?,?,?,?,?,?)";
			ps=con.prepareStatement(sql3);
			ps.setInt(1, user_id);
			ps.setInt(2, category_id);
			ps.setInt(3, height);
			ps.setInt(4, weight);
			ps.setDouble(5, bmi);
			ps.setString(6, sys_date);
			int result1= ps.executeUpdate();
			

			if(result1!=0){
				return "SUCCESS";
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
		else{
			try{
				
				con= DBConnection.createConnection();
				
				String sql1="select user_id from sm_user_registration where username=?";
				ps1=con.prepareStatement(sql1);
				ps1.setString(1, username);
				rs= ps1.executeQuery();
				while(rs.next()){
					user_id=rs.getInt("user_id");
				}
				System.out.println("user_id"+user_id);
				String sql2="select category_id from sm_category where classification=?";
				ps2=con.prepareStatement(sql2);
				ps2.setString(1, result);
				rs1= ps2.executeQuery();
				while(rs1.next()){
					category_id=rs1.getInt("category_id");
				}
				System.out.println("cat_id"+category_id);
				String sql4="select sysdate from dual";
				ps3=con.prepareStatement(sql4);
				rs2=ps3.executeQuery();
				if(rs2.next()==true){
					sys_date=rs2.getString("sysdate");
				}
				System.out.println(sys_date);
					
				
					
			
				String sql3="insert into sm_bmi_details(user_id,category_id, height,weight,bmi_calculated_value,calculated_date) values(?,?,?,?,?,?)";
				ps=con.prepareStatement(sql3);
				ps.setInt(1, user_id);
				ps.setInt(2, category_id);
				ps.setInt(3, height_in_cm);
				ps.setFloat(4, weight_in_kg);
				ps.setDouble(5, bmi);
				ps.setString(6, sys_date);
				int result1= ps.executeUpdate();
				

				if(result1!=0){
					return "SUCCESS";
				}
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
		return "FAILED";
	}

}
