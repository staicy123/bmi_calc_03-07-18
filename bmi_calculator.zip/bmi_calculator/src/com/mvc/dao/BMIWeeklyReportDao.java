package com.mvc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mvc.bean.BMIWeeklyReportBean;
import com.mvc.util.DBConnection;

public class BMIWeeklyReportDao {


	public List<BMIWeeklyReportBean> getUserWeeklyReport(String username,BMIWeeklyReportBean bmiweeklyreportbean) throws ClassNotFoundException, SQLException{

		Class<?> bmiweeklyreport = Class.forName("com.mvc.bean.BMIWeeklyReportBean");
	
		Connection con = null;
		List<BMIWeeklyReportBean> bmiweeklyreportbmilist = new ArrayList<BMIWeeklyReportBean>();

		ResultSet resultSet = null;
		ResultSet resultSet1 = null;
		ResultSet resultSet2 = null;
		ResultSet resultSet3 = null;
		PreparedStatement ps = null;
		PreparedStatement ps1= null;
		PreparedStatement ps2= null;
		PreparedStatement ps3=null;
		String week_date=null;
		int user_id=0;
		String sys_date=null;
		/*vacancy=(VacancyList) vacant.newInstance();*/


		try
		{

			con = DBConnection.createConnection();
			ps = con.prepareStatement("select next_day(sysdate(),'Mon')-7");
			resultSet=ps.executeQuery();
			if(resultSet.next())
			{

				week_date= resultSet.getString(1);
			}
			System.out.println("week_date"+week_date);
			ps1 = con.prepareStatement("select user_id from sm_user_registration where username=?");
			ps1.setString(1, username);
			resultSet1=ps1.executeQuery();
			if(resultSet1.next()==true)
			{

				user_id= resultSet1.getInt("user_id");
			}

			System.out.println("user_id"+user_id);
			System.out.println("username:"+username);
			ps2 = con.prepareStatement("select sysdate()");

			resultSet2=ps2.executeQuery();
			if(resultSet2.next())
			{

				sys_date= resultSet2.getString("sysdate()");
			}
			System.out.println("sys_date"+sys_date);

			ps3= con.prepareStatement("select b.height,b.weight,b.bmi_calculated_value,c.classification,c.obesity_classification,c.relative_risk_classification "
					+ "from sm_bmi_details  b inner join sm_category c on b.category_id=c.category_id where b.user_id=?  "
					+ "AND (b.calculated_date between ?  AND ?)");
			ps3.setInt(1, user_id);
			ps3.setString(2,week_date);
			ps3.setString(3,sys_date);
			resultSet3 = ps3.executeQuery();
			while(resultSet3.next())
			{
				bmiweeklyreportbean	=(BMIWeeklyReportBean) bmiweeklyreport.newInstance();
				bmiweeklyreportbean.setHeight(resultSet3.getInt(1));
				bmiweeklyreportbean.setWeight(resultSet3.getInt(2));
				bmiweeklyreportbean.setBmi_value(resultSet3.getDouble(3));
				bmiweeklyreportbean.setCategory_name(resultSet3.getString(4));
				bmiweeklyreportbean.setObesity_classification(resultSet3.getString(5));
				bmiweeklyreportbean.setRelative_risk(resultSet3.getString(6));
				bmiweeklyreportbmilist.add(bmiweeklyreportbean);	
			}

		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (Exception e) {
		
			e.printStackTrace();

		}
		return bmiweeklyreportbmilist;
	
}
}
