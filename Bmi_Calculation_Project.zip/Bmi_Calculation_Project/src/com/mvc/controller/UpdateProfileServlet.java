package com.mvc.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mvc.bean.RegisterBean;
import com.mvc.dao.RegisterDao;

/**
 * Servlet implementation class UpdateProfileServlet
 */
@WebServlet("/UpdateProfileServlet")
public class UpdateProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateProfileServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		String username=(String)request.getSession().getAttribute("username");
		HttpSession session = request.getSession();
		String firstname=request.getParameter("firstname");
		String lastname=request.getParameter("lastname");
		String dob=request.getParameter("dob");
		String phone=request.getParameter("phone");
		String email=request.getParameter("email");
		RegisterBean regbean = new RegisterBean();
		regbean.setFirstname(firstname);
		regbean.setLastname(lastname);
		regbean.setDob(dob);
		regbean.setPhone_number(phone);
		regbean.setEmail(email);
		RegisterDao regdao = new RegisterDao();
		String message=regdao.updateRegistration(regbean, username);
		if(message.equals("Success")){
			
			session.setAttribute("username", username);
			request.setAttribute("errMessage", "Your Profile have been Successfully Updated"); 
			request.getRequestDispatcher("/edit-registration.jsp").forward(request, response);
			
			
		}
		else{
			session.setAttribute("username", username);
			request.setAttribute("errMessage", "Unable to update the profile"); 
			request.getRequestDispatcher("/edit-registration.jsp").forward(request, response);
		}
	}

}
