package com.mvc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.mvc.bean.LoginBean;
import com.mvc.util.DBConnection;
public class LoginDao {


	public String authenticateUser(LoginBean loginBean)
	{

		String userName = loginBean.getUserName(); //Keeping user entered values in temporary variables.
		String password = loginBean.getPassword();

		Connection con = null;
		Statement statement = null;
		ResultSet resultSet = null;
		ResultSet resultSet1 = null;
		PreparedStatement ps = null;
		PreparedStatement ps1= null;

		String userNameDB = "";
		String passwordDB = "";


		try
		{
			
			con = DBConnection.createConnection();
			ps = con.prepareStatement("select username,password from sm_user_registration where username=? AND password=?");
			ps.setString(1, userName);
			ps.setString(2, password);
			resultSet = ps.executeQuery(); 

			ps1 = con.prepareStatement("select username,password from sm_admin where username=? AND password=?");
			ps1.setString(1, userName);
			ps1.setString(2, password);
			resultSet1 = ps1.executeQuery();
			if(resultSet.next()) 
			{
				userNameDB = resultSet.getString("username"); 
				passwordDB = resultSet.getString("password");
				System.out.println("username"+userNameDB);

				if(userName.equals(userNameDB) && password.equals(passwordDB))
				{
					return "SUCCESS"; 
				}

			}
			else if(resultSet1.next()){
				userNameDB = resultSet1.getString("username"); //fetch the values present in database
				passwordDB = resultSet1.getString("password");
				
				System.out.println("username"+userNameDB);
				System.out.println("username"+passwordDB);

				if(userName.equals(userNameDB) && password.equals(passwordDB))
				{
					return "SUCCESS1"; 
				}

				
			}

		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return "NOT_USER"; // Just returning appropriate message otherwise

	}
}
