package com.mvc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.mvc.bean.BMICalculationBean;

import com.mvc.util.DBConnection1;

public class BMICalculationDao {
	
	public String getBMIValue(BMICalculationBean bmicalculationbean,String username,String result){
		
		int height=bmicalculationbean.getInch();
		int weight= bmicalculationbean.getPounds();
		double bmi= bmicalculationbean.getBmi_calculated_value();
		 
		
		Connection con= null;
		PreparedStatement ps=null;
		PreparedStatement ps1=null;
		PreparedStatement ps2=null;
	
		ResultSet rs = null;
		ResultSet rs1 = null;
		int user_id=0;
		int category_id=0;
		System.out.println("result is "+result);
		
		try{
			
			con= DBConnection1.createConnection();
			
			String sql1="select user_id from user_registration where username=?";
			ps1=con.prepareStatement(sql1);
			ps1.setString(1, username);
			rs= ps1.executeQuery();
			while(rs.next()){
				user_id=rs.getInt("user_id");
			}
			String sql2="select category_id from sm_category where classification=?";
			ps2=con.prepareStatement(sql2);
			ps2.setString(1, result);
			rs1= ps2.executeQuery();
			while(rs1.next()){
				category_id=rs1.getInt("category_id");
			}
			System.out.println("cat_id"+category_id);
			String sys_date="select sysdate()";
			
			String sql3="insert into sm_bmi_detail(user_id,category_id, height,weight,bmi_calculated_value,calculated_date) values(?,?,?,?,?,?)";
			ps=con.prepareStatement(sql3);
			ps.setInt(1, user_id);
			ps.setInt(2, category_id);
			ps.setInt(3, height);
			ps.setInt(4, weight);
			ps.setDouble(5, bmi);
			ps.setString(6, sys_date);
			
			int result1= ps.executeUpdate();
			if(result1!=0){
				return "Success";
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return "Failed";
	}

}
