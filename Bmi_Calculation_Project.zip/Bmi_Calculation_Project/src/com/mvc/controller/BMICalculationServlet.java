package com.mvc.controller;

import java.io.IOException;
import java.text.DecimalFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.mvc.bean.BMICalculationBean;
import com.mvc.dao.BMICalculationDao;

/**
 * Servlet implementation class BMICalculationServlet
 */
@WebServlet("/BMICalculationServlet")
public class BMICalculationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BMICalculationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 String username=(String)request.getSession().getAttribute("username");
		int height_in_ft= Integer.parseInt(request.getParameter("height_in_ft"));
		int height_in_inch= Integer.parseInt(request.getParameter("height_in_inch"));
		int weight= Integer.parseInt(request.getParameter("weight"));
		int height=  Integer.parseInt(request.getParameter("height"));
		
		BMICalculationDao bmicalculationdao = new BMICalculationDao();
		
		
		
		if(height_in_ft==0 && height_in_inch==0)
		{	
			double number= 703.07;
			int test1=(height)*(height);
			double test =Double.parseDouble(new DecimalFormat("##.##").format(weight/test1));
			double bmi_calculation =  ((test) * number);
			String result=bmiPrediction(bmi_calculation);
			
			
			BMICalculationBean bmicalculationbean= new BMICalculationBean(height,weight,bmi_calculation);
			bmicalculationdao.getBMIValue(bmicalculationbean,username,result);
			
		}
	}
	public String bmiPrediction(double bmi_calculation){

		String result;
		if(bmi_calculation<18.55){

			result="Underweight";
		}
		else if(bmi_calculation>=18.55 && bmi_calculation<=24.99){
			result="Normal";
		}

		else if(bmi_calculation>=25.00 && bmi_calculation<=29.99){

			result="Overweight";
			//send the mail to the user
		}
		else if(bmi_calculation>=30.00 && bmi_calculation<=34.99){

			result="obese class 1"; 
		}
		else if(bmi_calculation>=35.00 && bmi_calculation<=39.99){

			result="obese class 2"; 
		}
		else {

			result="extremely obese class 3"; 
		}

		return result;
}
}	
