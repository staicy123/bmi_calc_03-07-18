package com.mvc.controller;

import java.io.IOException;
import java.text.DecimalFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mvc.bean.BMICalculationBean;
import com.mvc.dao.BMICalculationDao;

/**
 * Servlet implementation class BMICalculationServlet
 */
@WebServlet("/BMICalculationServlet")
public class BMICalculationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	;
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BMICalculationServlet() {
		super();
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username=(String)request.getSession().getAttribute("username");
		String bmical = request.getParameter("common");
		HttpSession session = request.getSession();

		BMICalculationDao bmicalculationdao = new BMICalculationDao();


		if(bmical.equals("Calculate")){
			int feet_to_inches;
			int height_in_ft= Integer.parseInt(request.getParameter("height_in_ft"));
			int height_in_inch= Integer.parseInt(request.getParameter("height_in_inch"));
			int weight= Integer.parseInt(request.getParameter("weight"));

			System.out.println(height_in_ft);
			System.out.println(height_in_inch);
			System.out.println(weight);
			System.out.println("username"+username);
			double number= 703.07;
			feet_to_inches=(height_in_ft*12)+height_in_inch;
			System.out.println(feet_to_inches);
			int test1=(feet_to_inches)*(feet_to_inches);
			System.out.println(test1);
			double bmi_calculation =Double.parseDouble(new DecimalFormat("##.##").format((1.0*weight/test1)*number));

			System.out.println("bmi value"+bmi_calculation);
			String result=bmiPrediction(bmi_calculation);
			System.out.println(result);

			BMICalculationBean bmicalculationbean= new BMICalculationBean(feet_to_inches,weight,bmi_calculation);
			String insertedValue=bmicalculationdao.getBMIValue(bmicalculationbean,username,result);
			if(insertedValue.equals("SUCCESS")){
				
				session.setAttribute("username", username);

				request.setAttribute("bmi",bmi_calculation);
				request.setAttribute("result",result);
				request.setAttribute("feet",height_in_ft);
				request.setAttribute("inch",height_in_inch);
				request.setAttribute("weight",weight);
			
				request.getRequestDispatcher("/bmi-calculation2.jsp").forward(request, response);
			}
			else{
				request.getRequestDispatcher("/home.jsp").forward(request, response);

			}
		}
		else if(bmical.equals("CalculateBMI")){

			calculateBmiinKg(request,response);
		}

	}
	protected void calculateBmiinKg(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String username=(String)request.getSession().getAttribute("username");
		BMICalculationDao bmicalculationdao = new BMICalculationDao();
		float weight_in_kg =Float.parseFloat(request.getParameter("weight_in_kg"));
		int height_in_cm =Integer.parseInt(request.getParameter("height_in_cm"));
		HttpSession session = request.getSession();
		double bmi_calc= (1.0*weight_in_kg/((height_in_cm * height_in_cm)*0.01))*100;
		System.out.println(bmi_calc);
		double bmi_calculation1 =Double.parseDouble(new DecimalFormat("##.##").format(bmi_calc));
		System.out.println("bmi value"+bmi_calculation1);
		String result=bmiPrediction(bmi_calculation1);
		System.out.println(result);
		BMICalculationBean bmicalculationbean= new BMICalculationBean(height_in_cm,weight_in_kg,bmi_calculation1);
		String insertedValue=bmicalculationdao.getBMIValue(bmicalculationbean,username,result);
		if(insertedValue.equals("SUCCESS")){
			
			session.setAttribute("username", username);
			request.setAttribute("bmi",bmi_calculation1);
			request.setAttribute("result",result);
			request.setAttribute("height",height_in_cm);

			request.setAttribute("weight",weight_in_kg);
			
			request.getRequestDispatcher("/bmi-calculation3.jsp").forward(request, response);
		}
		else{
			session.setAttribute("username", username);
			request.getRequestDispatcher("/home.jsp").forward(request, response);

		}
	}






	public String bmiPrediction(double bmi_calculation){

		String result;
		if(bmi_calculation<18.55){

			result="underweight";
		}
		else if(bmi_calculation>=18.55 && bmi_calculation<=24.99){
			result="normal";
		}

		else if(bmi_calculation>=25.00 && bmi_calculation<=29.99){

			result="overweight";
			//send the mail to the user
		}
		else if(bmi_calculation>=30.00 && bmi_calculation<=34.99){

			result="obese class 1"; 
		}
		else if(bmi_calculation>=35.00 && bmi_calculation<=39.99){

			result="obese class 2"; 
		}
		else {

			result="extremely obese class 3"; 
		}

		return result;
	}
}	
