package com.mvc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mvc.bean.RegisterBean;
import com.mvc.util.DBConnection;
 
public class RegisterDao {
 
 public String registerUser(RegisterBean registerBean)
 {
 String firstName = registerBean.getFirstname();
String lastName= registerBean.getLastname();
 String email=registerBean.getEmail();
 String dob=registerBean.getDob();
String gender= registerBean.getGender();
 String phoneNumber=registerBean.getPhone_number();
 String userName =registerBean.getUsername();
 String password = registerBean.getPassword(); 

 
 Connection con = null;
 PreparedStatement preparedStatement = null;
 
 try
 {
 con = DBConnection.createConnection();
 String query = "insert into sm_user_registration(first_name,last_name,dob,gender,phone_number,email,username,password) values (?,?,?,?,?,?,?,?)"; //Insert user details into the table 'USERS'
 preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
 preparedStatement.setString(1, firstName);
 preparedStatement.setString(2, lastName);
 preparedStatement.setString(3, dob);
 preparedStatement.setString(4, gender);
 preparedStatement.setString(5, phoneNumber);
 preparedStatement.setString(6, email);
 preparedStatement.setString(7, userName);
 preparedStatement.setString(8, password);
 
 
 
 int i= preparedStatement.executeUpdate();
 
 if (i!=0)  //Just to ensure data has been inserted into the database
 return "SUCCESS"; 
 }
 catch(SQLException e)
 {
 e.printStackTrace();
 }
 
 return "Oops.. Something went wrong there..!";  // On failure, send a message from here.
 }
 
 
 public RegisterBean editRegistration(RegisterBean regbean, String username){
	 
	 System.out.println("username"+username);
	 Connection con = null;
	 PreparedStatement ps = null;
	 ResultSet rs = null;
	 PreparedStatement ps1 = null;
	 ResultSet rs1 = null;
	 int user_id=0;
	 try{
		 
		 con = DBConnection.createConnection();
		 ps = con.prepareStatement("select user_id from sm_user_registration where username=?");
		 ps.setString(1, username);
		 rs=ps.executeQuery();
		 if(rs.next()){
			 
			 user_id= rs.getInt("user_id");
		 }
		 System.out.println("user_id"+user_id);
		 ps1 = con.prepareStatement("select first_name,last_name,dob,phone_number,email from sm_user_registration where user_id=?");
		 ps1.setInt(1, user_id);
		 rs1=ps1.executeQuery();
		 if(rs1.next()){
			 regbean.setFirstname(rs1.getString(1));
			 regbean.setLastname(rs1.getString(2));
			 regbean.setDob(rs1.getString(3));
			 regbean.setPhone_number(rs1.getString(4));
			 regbean.setEmail(rs1.getString(5));
			 
		 }
		 
	 }
	 catch(SQLException e)
	 {
	 e.printStackTrace();
	 }
	 
	 return regbean;
 }
public String updateRegistration(RegisterBean regbean, String username){
	 
	 System.out.println("username"+username);
	 Connection con = null;
	 PreparedStatement ps = null;
	 ResultSet rs = null;
	 PreparedStatement ps1 = null;
	 ResultSet rs1 = null;
	 String firstname= regbean.getFirstname();
	 String lastname =regbean.getLastname();
	 String dob = regbean.getDob();
	 String phone = regbean.getPhone_number();
	 String email=regbean.getEmail();
	 int user_id=0;
	 try{
		 
		 con = DBConnection.createConnection();
		 ps = con.prepareStatement("select user_id from sm_user_registration where username=?");
		 ps.setString(1, username);
		 rs=ps.executeQuery();
		 if(rs.next()){
			 
			 user_id= rs.getInt("user_id");
		 }
		 System.out.println("user_id"+user_id);
		 ps1 = con.prepareStatement("update sm_user_registration set first_name=?,last_name=?,dob=?,phone_number=?,email=? where user_id=?");
		 ps1.setString(1, firstname);
		 ps1.setString(2, lastname);
		 ps1.setString(3, dob);
		 ps1.setString(4, phone);
		 ps1.setString(5, email);
		 ps1.setInt(6, user_id);
		 
		 ps1.executeUpdate();
		 return "Success";
		
	 }
	 catch(SQLException e)
	 {
	 e.printStackTrace();
	 }
	 
	 return "failed";
 }


}

