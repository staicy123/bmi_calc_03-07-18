package com.mvc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.mvc.bean.AddCategoryBean;

import com.mvc.util.DBConnection1;

public class AddCategoryDao {
	
	public boolean addCategory(AddCategoryBean addcategorybean){
		
		String category=addcategorybean.getCategory_name();
		String classification=addcategorybean.getClassification();
		String risk = addcategorybean.getRisk_classification();
		
		Connection con=null;
		PreparedStatement ps = null;
		
		try{
			
			con=DBConnection1.createConnection();
			String sql="insert into sm_category(classification,obesity_classification,relative_risk_classification) values(?,?,?)";
			ps=con.prepareStatement(sql);
			ps.setString(1, category);
			ps.setString(2, classification);
			ps.setString(3, risk);
			int i=ps.executeUpdate();
			if(i!=0)
				return true;
		}
		catch(Exception e){
			
			
			e.printStackTrace();
		}
		
		return false;
		
	}

}
