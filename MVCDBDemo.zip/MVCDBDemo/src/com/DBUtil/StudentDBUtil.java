package com.DBUtil;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import com.model.Student;

public class StudentDBUtil {
	private DataSource dataSource;

	public StudentDBUtil() {
		super();
	}

	public StudentDBUtil(DataSource dataSource) {
		super();
		this.dataSource = dataSource;
	}
	
	public List<Student> getAllStudents() throws SQLException{
		List<Student> studList=new ArrayList<Student>();
		Connection con=null;
		Statement stmt=null;
		ResultSet rs=null;
		try {
			con=dataSource.getConnection();
			stmt=con.createStatement();
			String sql="select * from amr_student";
			rs=stmt.executeQuery(sql);
			while(rs.next()){
				studList.add(new Student(rs.getInt("id"),rs.getString("fname"),rs.getString("lname"),rs.getString("email")));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(rs!=null){
				rs.close();
			}
			if(rs!=null){
				stmt.close();
			}
			if(rs!=null){
				con.close();
			}			
		}
		return studList;
	}
}
