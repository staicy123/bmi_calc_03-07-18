package com.mvc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mvc.bean.ChangePasswordBean;

import com.mvc.util.DBConnection;

public class ChangePasswordDao {
	public String updatePassword(ChangePasswordBean changepass,String username)
	{

		String oldpassword = changepass.getOldpassword(); //Keeping user entered values in temporary variables.
		String newpassword = changepass.getNewpassword();
		String password=null;
		Connection con = null;
	
		ResultSet resultSet = null;
	
		ResultSet resultSet2 = null;
		PreparedStatement ps = null;
		PreparedStatement ps1 = null;
		PreparedStatement ps2= null;
		PreparedStatement ps3= null;
		int user_id=0;
		System.out.println("username"+username);
		System.out.println("old password"+oldpassword);
		try
		{
			
			con = DBConnection.createConnection();
			ps = con.prepareStatement("select password,user_id from sm_user_registration where username=?");
			ps.setString(1, username);
			resultSet = ps.executeQuery(); 

			ps1 = con.prepareStatement("select password from sm_admin where username=?");
			ps1.setString(1, username);
		
			resultSet2 = ps1.executeQuery();
			if(resultSet.next()) 
			{
				password = resultSet.getString("password");
				user_id=resultSet.getInt("user_id");
				
				System.out.println("password"+password);

				if(oldpassword.equals(password))
				{
					ps2 = con.prepareStatement("update sm_user_registration set password=? where user_id=?");
					ps2.setString(1, newpassword);
					ps2.setInt(2, user_id);
					 ps2.executeUpdate(); 
					
						
						return "SUCCESS";
					
				}

			}
			else if(resultSet2.next()){
				password = resultSet2.getString("password");
				
				
				System.out.println("password"+password);

				if(oldpassword.equals(password))
				{
					ps3 = con.prepareStatement("update sm_admin set password=?");
					ps3.setString(1, newpassword);
					
					 ps3.executeUpdate(); 
					
						
						return "SUCCESS1";
					
				}
				
			}

		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return "NOT_USER"; // Just returning appropriate message otherwise

	}

}
