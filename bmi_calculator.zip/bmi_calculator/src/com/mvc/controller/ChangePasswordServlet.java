package com.mvc.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.ChangePasswordBean;

import com.mvc.dao.ChangePasswordDao;


/**
 * Servlet implementation class ChangePasswordServlet
 */
@WebServlet("/ChangePasswordServlet")
public class ChangePasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChangePasswordServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String oldpassword = request.getParameter("oldpassword");
		String newpassword = request.getParameter("newpassword");
		String user_name=(String)request.getSession().getAttribute("username");
		System.out.println("servlet name"+user_name);
		ChangePasswordBean passwordBean = new ChangePasswordBean(); 

		passwordBean.setOldpassword(oldpassword);
		passwordBean.setNewpassword(newpassword);

		ChangePasswordDao changepassword = new ChangePasswordDao(); 

		String userValidate = changepassword.updatePassword(passwordBean,user_name);

		if(userValidate.equals("SUCCESS")) 
		{
			
			request.setAttribute("errMessage", "Your Password have been Successfully Changed"); 
			request.getRequestDispatcher("/changepassword.jsp").forward(request, response);
		}
		else if(userValidate.equals("SUCCESS1")){
			
			request.setAttribute("errMessage", "Your Password is Changed Successfully"); 
			request.getRequestDispatcher("/changepassword1.jsp").forward(request, response);
			
		}


		else
		{
			         
            
			request.setAttribute("errMessage", "Unable to change password"); 
			request.getRequestDispatcher("/changepassword.jsp").forward(request, response);
		}
	}

	

}
